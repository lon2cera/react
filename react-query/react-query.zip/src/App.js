import './App.css';
import InfinityExample from './components/InfinityExample';

function App() {
  return (
    <div >
      <InfinityExample/>
    </div>
  );
}

export default App;
